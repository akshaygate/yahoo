package Configuration;

public class Configuratis {
	public static String  driver = "C:\\Users\\R\\eclipse-Abhay\\yahooproject\\src\\main\\resources\\chromedriver.exe";
	public static String url = "https://login.yahoo.com/account/create?.intl=us&specId=yidReg&done=https%3A%2F%2Fwww.yahoo.com"; 
	public static String exelsheet ="C:\\Users\\R\\eclipse-Abhay\\yahooproject\\src\\test\\resources\\refaranceBook1.xlsx";
	public static String Screenshotpath ="C:\\Users\\R\\eclipse-Abhay\\yahooproject\\target\\Screenshot";
}
