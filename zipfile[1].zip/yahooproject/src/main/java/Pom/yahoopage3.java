package Pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class yahoopage3 {
	@FindBy(xpath="//button[@name='verifyCode']")private WebElement verify;
	public yahoopage3(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	public String yahoopage3verify(String username) {
		verify.sendKeys("12345");
		return username;
	}
}
