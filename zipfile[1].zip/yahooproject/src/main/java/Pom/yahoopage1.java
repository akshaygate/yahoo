package Pom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class yahoopage1<driver> {
	@FindBy(xpath="//input[@id='usernamereg-firstName']")private WebElement FN;
	@FindBy(xpath="//input[@id='usernamereg-lastName']")private WebElement LN;
	@FindBy(xpath="//input[@id='usernamereg-userId']")private WebElement email;
	@FindBy(xpath="//input[@id='usernamereg-password']")private WebElement PWD;
	@FindBy(xpath="//input[@id='usernamereg-birthYear']")private WebElement Year;
	@FindBy(xpath="//button[@id='reg-submit-button']")private WebElement BTN;
	
	public yahoopage1(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	public void yahoopage1fisrstname(String username) {
		FN.sendKeys("Akshay");
	}
	public void yahoopage1lastname(String username) {
		LN.sendKeys("Gate");
	}
	public void yahoopage1email(String username) {
		email.sendKeys("gateakshay");
	}
	public void yahoopage1password(String username) {
		PWD.sendKeys("Vaibhav@8555");
	}
	public void yahoopage1year(String username) {
		Year.sendKeys("1997");
	}
	public void signupbtn() {
		BTN.click();
	}
}
