package Pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class yahoopage2 {
	
	@FindBy(xpath="//select[@type='select']")private WebElement reg;
	@FindBy(xpath="//input[@type='tel']")private WebElement mobno;
	@FindBy(xpath="//button[@id='reg-submit-button']")private WebElement code;
	public yahoopage2(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	public void yahoopage2region(String username) {
		mobno.sendKeys("+91");
	}
	public void yahoopage2mobno(String username) {
		mobno.sendKeys("8888629545");
	}
	public void sendcode() {
		code.click();
	}
}
