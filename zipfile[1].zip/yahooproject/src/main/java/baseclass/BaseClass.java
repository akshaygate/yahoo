package baseclass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BaseClass {
	 WebDriver driver;
	public WebDriver initaliBrowser() {
		ChromeOptions Option = new ChromeOptions();
		Option.addArguments("..disable notifaction...");
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\R\\\\eclipse-Abhay\\\\yahooproject\\\\src\\\\main\\\\resources\\\\chromedriver.exe");
		driver=new ChromeDriver(Option);
		driver.manage().window().maximize();
		driver.get("https://login.yahoo.com/account/create?.intl=us&specId=yidregsimplified&done=https%3A%2F%2Fwww.yahoo.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		return driver;
		
	}

}
