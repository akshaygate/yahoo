package baseclass;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class Utility {
	public static String getTestData(int rowindex,int colindex) throws EncryptedDocumentException, IOException {
		FileInputStream file = new FileInputStream("C:\\Users\\R\\eclipse-Abhay\\yahooproject\\src\\test\\resources\\refaranceBook1.xlsx");
		Sheet sh = (Sheet) WorkbookFactory.create(file).getSheet("Sheet");
		String value = ((org.apache.poi.ss.usermodel.Sheet) sh).getRow(rowindex).getCell(colindex).getStringCellValue();
		return value; 
	}
	 public static void capturescreenshot(WebDriver driver,String TCID) throws IOException {
		 File str =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 File dest = new File("C:\\Users\\R\\eclipse-Abhay\\yahooproject\\target\\Screenshot"+TCID+"image.jpg");
		 FileHandler.copy(str, dest);
	}

}
