 package Testclass;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Pom.yahoopage1;
import Pom.yahoopage2;
import Pom.yahoopage3;
import baseclass.BaseClass;
import baseclass.Utility;

public class YahooTest1 extends BaseClass{
	WebDriver driver;
	yahoopage1 login1;
	yahoopage2 login2;
	yahoopage3 login3;
	 YahooTest1 test;
	 String TCID;
	 ITestResult result;
	@BeforeClass
     public void OpenBrowser() {
    	   driver=initaliBrowser();
    	   login1 = new yahoopage1(driver);
    	   login2 = new yahoopage2(driver);
    	   login3 = new yahoopage3(driver);
           test = new YahooTest1();
     }
	@BeforeMethod
	public void logintoapplication() throws InterruptedException {
		Reporter.log("..log in application..");
		login1.yahoopage1fisrstname("Akshay");
		login1.yahoopage1lastname("Gate");
		login1.yahoopage1email("gateakshay");
		login1.yahoopage1password("Vaibha@8555");
		login1.yahoopage1year("1997");
		login1.signupbtn();
		Thread.sleep(4000);
		login2.yahoopage2region("+91");
		login2.yahoopage2mobno("8888629545");
		login2.sendcode();
		Thread.sleep(4000);
		login3.yahoopage3verify("12345");
	}
	@Test
	public void verifyuserid() {
		Reporter.log("..to verify user should be rgistor already");
		String expeuser="Akshay";
		String actuser =login3.yahoopage3verify("Vaibhav");
		Assert.assertEquals(expeuser, actuser);
	}
	@Test
	public void checkmobileno() {
		Reporter.log("to check mo no is valid or not");
		String expeuser="8888629545";
		String actuser =login3.yahoopage3verify("918888629545");
		Assert.assertEquals(expeuser, actuser);
	}
	@Test
	public void verifylogin() {
		Reporter.log("to check regarding terms and condision");
		String expeuser="login succussfully";
		String actuser =login3.yahoopage3verify("Eroor");
		Assert.assertEquals(expeuser, actuser);
	}
	@AfterMethod
	public void yahooHomePage() throws IOException {
		if(result.getStatus()==ITestResult.FAILURE) {
			Utility.capturescreenshot(driver, TCID);
		}
		
	}
}
		
	
